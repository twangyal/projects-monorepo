#!/bin/bash
SOLVER_PATH="/home/runner/work/projects-monorepo/projects-monorepo/upstream/target/cpu/release/ppf-contact-solver"

if [ ! -f "$SOLVER_PATH" ]; then
    echo "Error: Solver does not exist at $SOLVER_PATH" >&2
    exit 1
fi

"$SOLVER_PATH" --path "/home/runner/work/projects-monorepo/projects-monorepo/ppf-native-cache/sessions/cpu-tensile-stiff/session" --output "/home/runner/work/projects-monorepo/projects-monorepo/ppf-native-cache/sessions/cpu-tensile-stiff/session/output" "$@"
