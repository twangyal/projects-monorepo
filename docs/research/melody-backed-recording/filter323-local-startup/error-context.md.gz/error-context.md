# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: backed-recording.spec.ts >> Stop playback and controlled pagehide cancel the whole backed session without publishing partial PCM
- Location: tests/backed-recording.spec.ts:39:1

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0.2
Received:   -Infinity

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - link "Skip to composition" [ref=e2] [cursor=pointer]:
    - /url: "#workspace"
  - generic [ref=e3]:
    - banner [ref=e4]:
      - generic [ref=e5]:
        - generic [aria-hidden] [ref=e6]:
          - text: m
          - generic [ref=e7]: ♪
        - generic [ref=e8]:
          - paragraph [ref=e9]: FROM A HUM TO SOMETHING MORE
          - heading "Melody Studio" [level=1] [ref=e10]
      - generic [ref=e11]: ● Made here. Stays here.
    - region "Workspace tools" [ref=e12]:
      - group "Choose workspace tools" [ref=e13]:
        - button "Compose" [ref=e14] [cursor=pointer]
        - button "Capture" [ref=e15] [cursor=pointer]
        - button "Sound" [ref=e16] [cursor=pointer]
        - button "Notes" [ref=e17] [cursor=pointer]
        - button "Arrange" [ref=e18] [cursor=pointer]
        - button "Reference" [ref=e19] [cursor=pointer]
        - button "Project & export" [ref=e20] [cursor=pointer]
      - generic [ref=e21]:
        - button "Back to compose" [ref=e22] [cursor=pointer]
        - button "Focus workspace" [active] [pressed] [ref=e23] [cursor=pointer]
        - button "Stop audio" [ref=e24] [cursor=pointer]
      - group [ref=e25]:
        - generic "About these tools" [ref=e26] [cursor=pointer]
    - main [ref=e28]:
      - region "Project settings" [ref=e29]:
        - generic [ref=e30]:
          - generic [ref=e31]: Project title
          - textbox "Project title" [ref=e32]: Original backed recording Ω
        - generic [ref=e33]:
          - generic [ref=e34]: Tempo (BPM)
          - spinbutton "Tempo (BPM)" [ref=e35]: "240"
        - generic [ref=e36]:
          - button "Play composition" [ref=e37] [cursor=pointer]:
            - generic [aria-hidden] [ref=e38]: ▶
            - text: Play
          - button "Stop playback" [disabled] [ref=e39]: ■ Stop
        - generic [ref=e40]:
          - button "Undo" [ref=e41] [cursor=pointer]
          - button "Redo" [disabled] [ref=e42]
        - generic [ref=e43]: 4 tracks · 12 notes
      - status [ref=e44]: "Could not record with backing: The microphone audio frames were interrupted. Your prior take is unchanged. Check your microphone and try again explicitly."
      - region [ref=e45]:
        - generic [ref=e46]:
          - paragraph [ref=e47]: 01 / CATCH AN IDEA
          - heading "Your next song starts with a hum." [level=2] [ref=e48]
          - paragraph [ref=e49]: Sing one clear melody, then make it your own.Record up to 20 seconds or bring in an audio file.
        - generic [ref=e50]:
          - generic [ref=e51]:
            - button "Record melody" [ref=e52] [cursor=pointer]
            - button "Record with backing" [ref=e54] [cursor=pointer]
            - generic [ref=e55] [cursor=pointer]:
              - text: Import audio
              - button "Import audio file" [ref=e56]
          - generic [ref=e57]:
            - button "Try demo melody" [ref=e58] [cursor=pointer]
            - generic [ref=e59]: No microphone needed
          - paragraph [ref=e60]: Record with backing uses the other committed tracks and a four-beat count-in. Apply or discard unapplied fields and suggestions first. Use headphones, then listen back and check the detected timing.
      - region "Composition editor" [ref=e61]:
        - complementary [ref=e62]:
          - generic [ref=e63]:
            - generic [ref=e64]:
              - paragraph [ref=e65]: 02 / BUILD YOUR SOUND
              - heading "Tracks" [level=2] [ref=e66]
            - button "Add track" [ref=e67] [cursor=pointer]: +
          - generic [ref=e68]:
            - 'button "Select track: Destination high notes" [pressed] [ref=e69] [cursor=pointer]':
              - generic [aria-hidden] [ref=e70]: "01"
              - generic [ref=e71]:
                - strong [ref=e72]: Destination high notes
                - generic [ref=e73]: 8 notes · Soft keys
            - 'button "Select track: Audible low backing" [ref=e74] [cursor=pointer]':
              - generic [aria-hidden] [ref=e75]: "02"
              - generic [ref=e76]:
                - strong [ref=e77]: Audible low backing
                - generic [ref=e78]: 2 notes · Soft keys
            - 'button "Select track: Muted high sentinel" [ref=e79] [cursor=pointer]':
              - generic [aria-hidden] [ref=e80]: "03"
              - generic [ref=e81]:
                - strong [ref=e82]: Muted high sentinel
                - generic [ref=e83]: 1 notes · muted
            - 'button "Select track: Zero volume sentinel" [ref=e84] [cursor=pointer]':
              - generic [aria-hidden] [ref=e85]: "04"
              - generic [ref=e86]:
                - strong [ref=e87]: Zero volume sentinel
                - generic [ref=e88]: 1 notes · Soft keys
          - generic [ref=e89]:
            - generic [ref=e90]: Track name
            - textbox "Track name" [ref=e91]: Destination high notes
            - generic [ref=e92]: Instrument
            - combobox "Instrument" [ref=e93]:
              - option "Soft keys" [selected]
              - option "Warm flute"
              - option "Bright synth"
              - option "Drum kit"
            - generic [ref=e94]:
              - text: Track volume
              - generic [ref=e95]: 100%
            - slider "Track volume 100%" [ref=e96]: "1"
            - generic [ref=e97]:
              - checkbox "Mute track" [ref=e98]
              - text: Mute track
            - group "Stereo mix" [ref=e99]:
              - generic [ref=e101]:
                - text: Pan
                - generic [ref=e102]: Centre
              - slider "Pan Centre" [ref=e103]: "0"
              - generic [ref=e104]:
                - text: Reverb send
                - generic [ref=e105]: 0%
              - slider "Reverb send 0%" [ref=e106]: "0"
              - paragraph [ref=e107]: Shared reverb bus for all tracks
              - generic [ref=e108]:
                - text: Reverb size
                - generic [ref=e109]: 50%
              - slider "Reverb size 50%" [ref=e110]: "0.5"
              - generic [ref=e111]:
                - text: Reverb return
                - generic [ref=e112]: 50%
              - slider "Reverb return 50%" [ref=e113]: "0.5"
              - paragraph [ref=e114]: All tracks are centred without reverb, so playback and WAV export stay mono.
            - group "Pan automation" [ref=e115]:
              - generic [ref=e117]:
                - checkbox "Enable pan curve" [ref=e118]
                - text: Enable pan curve
              - generic [ref=e119]: Pan curve points
              - textbox "Pan curve points" [ref=e120]: 1 -1 5 1
              - button "Apply pan curve" [ref=e121] [cursor=pointer]
              - button "Discard pan curve edits" [ref=e122] [cursor=pointer]
              - img "Committed pan curve" [ref=e123]
              - paragraph [ref=e125]:
                - text: "Static Pan active. Enter one song beat and position per line:"
                - code [ref=e126]: 1 -1
                - text: . Beats 1–513; positions −1 = left, 0 = centre, +1 = right. Up to 64 increasing points. Linear between points, held endpoints. Applies to the dry track, including echo/release; reverb keeps its mono pre-pan send. Apply unchecked to restore retained static Pan. Drafts are not played or exported; both MIDI exports omit pan automation.
            - group "Sound envelope" [ref=e127]:
              - generic [ref=e129]: Attack (seconds)
              - spinbutton "Attack (seconds)" [ref=e130]: "0.01"
              - generic [ref=e131]: Decay (seconds)
              - spinbutton "Decay (seconds)" [ref=e132]: "0"
              - generic [ref=e133]: Sustain level
              - spinbutton "Sustain level" [ref=e134]: "1"
              - generic [ref=e135]: Release (seconds)
              - spinbutton "Release (seconds)" [ref=e136]: "0.08"
              - button "Apply sound envelope" [ref=e137] [cursor=pointer]
              - button "Discard sound edits" [ref=e138] [cursor=pointer]
              - paragraph [ref=e139]: Linear attack, decay, sustain and release. Project/WAV retain this sound; MIDI does not carry custom envelopes.
            - group "Sound filter" [ref=e140]:
              - generic [ref=e142]:
                - checkbox "Enable low-pass filter" [ref=e143]
                - text: Enable low-pass filter
              - generic [ref=e144]: Filter cutoff (Hz)
              - spinbutton "Filter cutoff (Hz)" [ref=e145]: "8000"
              - generic [ref=e146]: Filter resonance (Q)
              - spinbutton "Filter resonance (Q)" [ref=e147]: "0.707"
              - generic [ref=e148]:
                - checkbox "Enable cutoff curve" [ref=e149]
                - text: Enable cutoff curve
              - generic [ref=e150]: Cutoff curve points
              - textbox "Cutoff curve points" [ref=e151]: 1 8000 5 300
              - paragraph [ref=e152]:
                - text: Enable low-pass filter and Apply to hear the curve. One song beat and cutoff Hz per line, such as
                - code [ref=e153]: 1 8000
                - text: . Beats1–513; cutoff20–10000Hz; up to64 increasing points. Linear interpolation with held endpoints replaces static cutoff; Q stays fixed. Disable curve and Apply to restore the retained cutoff, or disable filter and Apply to remove both. Each voice follows song time through its release; echoes repeat that filtered voice. MIDI omits this effect.
              - button "Apply sound filter" [ref=e154] [cursor=pointer]
              - button "Discard filter edits" [ref=e155] [cursor=pointer]
              - paragraph [ref=e156]: Cut bright harmonics; raise Q for emphasis near the cutoff. Apply with Enable unchecked to bypass. Project/WAV retain this sound; MIDI does not.
            - group "Sound echo" [ref=e157]:
              - generic [ref=e159]:
                - checkbox "Enable rhythmic echo" [ref=e160]
                - text: Enable rhythmic echo
              - generic [ref=e161]: Echo spacing (beats)
              - spinbutton "Echo spacing (beats)" [ref=e162]: "1"
              - generic [ref=e163]: Echo decay
              - spinbutton "Echo decay" [ref=e164]: "0.5"
              - generic [ref=e165]: Echo repeats
              - spinbutton "Echo repeats" [ref=e166]: "3"
              - button "Apply sound echo" [ref=e167] [cursor=pointer]
              - button "Discard echo edits" [ref=e168] [cursor=pointer]
              - paragraph [ref=e169]: Repeat each voice at beat intervals with decaying level. Full WAV includes the tail; sections crop it. MIDI omits echo.
            - group "Harmonic tone" [ref=e170]:
              - generic [ref=e172]:
                - checkbox "Enable harmonic tone" [ref=e173]
                - text: Enable harmonic tone
              - generic [ref=e174]: Harmonic 1 amplitude
              - textbox "Harmonic 1 amplitude" [ref=e175]: "1"
              - generic [ref=e176]: Harmonic 2 amplitude
              - textbox "Harmonic 2 amplitude" [ref=e177]: "0.5"
              - generic [ref=e178]: Harmonic 3 amplitude
              - textbox "Harmonic 3 amplitude" [ref=e179]: "0"
              - generic [ref=e180]: Harmonic 4 amplitude
              - textbox "Harmonic 4 amplitude" [ref=e181]: "0.25"
              - generic [ref=e182]: Harmonic 5 amplitude
              - textbox "Harmonic 5 amplitude" [ref=e183]: "0"
              - generic [ref=e184]: Harmonic 6 amplitude
              - textbox "Harmonic 6 amplitude" [ref=e185]: "0"
              - generic [ref=e186]: Harmonic 7 amplitude
              - textbox "Harmonic 7 amplitude" [ref=e187]: "0"
              - generic [ref=e188]: Harmonic 8 amplitude
              - textbox "Harmonic 8 amplitude" [ref=e189]: "0"
              - button "Apply harmonic tone" [ref=e190] [cursor=pointer]
              - button "Discard harmonic edits" [ref=e191] [cursor=pointer]
              - paragraph [ref=e192]: Selected instrument waveform active. Eight sine partials at 1–8×note frequency, amplitudes 0–1; at least one positive. Replaces the selected waveform before envelope/filter/echo. Normalize by total configured amplitude; partials at/above half the render sample rate are omitted. High notes may become quiet or silent. Apply unchecked to restore the instrument. Playback/WAV retain this tone; MIDI uses the base instrument and omits harmonics.
            - group "Volume ramp" [ref=e193]:
              - generic [ref=e195]:
                - checkbox "Enable volume ramp" [ref=e196]
                - text: Enable volume ramp
              - generic [ref=e197]: Ramp start beat
              - spinbutton "Ramp start beat" [ref=e198]: "1"
              - generic [ref=e199]: Ramp end beat
              - spinbutton "Ramp end beat" [ref=e200]: "5"
              - generic [ref=e201]: Ramp start level
              - spinbutton "Ramp start level" [ref=e202]: "1"
              - generic [ref=e203]: Ramp end level
              - spinbutton "Ramp end level" [ref=e204]: "0"
              - button "Apply volume ramp" [ref=e205] [cursor=pointer]
              - button "Discard volume ramp edits" [ref=e206] [cursor=pointer]
              - paragraph [ref=e207]: Fade sustained notes and echoes between song beats; hold the endpoint levels outside the ramp. Levels multiply track volume. Apply with Enable unchecked to bypass. Playback and WAV retain automation; MIDI omits it.
            - group "Volume breakpoint curve" [ref=e208]:
              - generic [ref=e210]:
                - checkbox "Enable volume curve" [ref=e211]
                - text: Enable volume curve
              - generic [ref=e212]: Volume curve points
              - textbox "Volume curve points" [ref=e213]: 1 1 5 0.25 9 1
              - button "Apply volume curve" [ref=e214] [cursor=pointer]
              - button "Discard volume curve edits" [ref=e215] [cursor=pointer]
              - img "Committed volume curve" [ref=e216]
              - paragraph [ref=e218]:
                - text: "No committed curve; unity gain shown. Enter one beat and level per line:"
                - code [ref=e219]: 1 1
                - text: . Beats1–513, levels0–1, strictly increasing, up to64points. Linear between points; hold end levels. Multiply track volume and any enabled volume ramp, including echoes and release. Apply with Enable unchecked to bypass. Raw text is not played or exported; MIDI omits automation.
            - button "Solo track" [ref=e220] [cursor=pointer]
            - button "Delete track" [ref=e221] [cursor=pointer]
          - generic [ref=e222]:
            - paragraph [ref=e223]: ARRANGE THIS TRACK
            - group "Track order" [ref=e224]:
              - button "Move track earlier" [disabled] [ref=e225]
              - button "Move track later" [ref=e226] [cursor=pointer]
            - paragraph [ref=e227]: Change layer order. Notes and reference recordings stay attached to their tracks. MIDI follows this track order. Finish unapplied edits first; Undo restores it.
            - button "Duplicate track" [ref=e228] [cursor=pointer]
            - group "Transpose track" [ref=e229]:
              - button "Transpose down an octave" [ref=e230] [cursor=pointer]: −12
              - button "Transpose down a semitone" [ref=e231] [cursor=pointer]: −1
              - button "Transpose up a semitone" [ref=e232] [cursor=pointer]: "+1"
              - button "Transpose up an octave" [ref=e233] [cursor=pointer]: "+12"
            - button "Repeat phrase" [ref=e234] [cursor=pointer]
            - paragraph [ref=e235]: Shift pitch by semitones. Notes stay within C2–C7 and 512 beats.
        - generic [ref=e236]:
          - generic [ref=e237]:
            - generic [ref=e238]:
              - heading "Destination high notes" [level=2] [ref=e239]
              - paragraph [ref=e240]: Select a note to edit its pitch and timing.
            - button "Add note" [ref=e241] [cursor=pointer]:
              - generic [aria-hidden] [ref=e242]: +
              - text: Add note
          - generic [ref=e243]:
            - generic [ref=e244]:
              - text: Piano roll tool
              - combobox "Piano roll tool" [ref=e245]:
                - option "Move notes" [selected]
                - option "Draw note"
            - generic [ref=e246]:
              - text: Snap movement
              - combobox "Snap movement" [ref=e247]:
                - option "Quarter beat" [selected]
                - option "Eighth beat"
                - option "Off"
          - group [ref=e248]:
            - generic "Piano roll help" [ref=e249] [cursor=pointer]
            - paragraph [ref=e250]: "Move or resize in increments from the original timing; fractional offsets stay intact. Drawing snaps the start and duration. Focus a note: arrows move; Shift+Left/Right resize; Enter opens its numeric fields. Draw on empty space, or use Add note."
          - generic "Piano roll" [ref=e251]:
            - generic [ref=e252]:
              - generic [ref=e253]:
                - generic [ref=e254]: "1"
                - generic [ref=e255]: "2"
                - generic [ref=e256]: "3"
                - generic [ref=e257]: "4"
                - generic [ref=e258]: "5"
                - generic [ref=e259]: "6"
                - generic [ref=e260]: "7"
                - generic [ref=e261]: "8"
              - generic [ref=e262]:
                - generic [ref=e263]: E6
                - generic [ref=e264]: D♯6
                - generic [ref=e265]: D6
                - generic [ref=e266]: C♯6
                - generic [ref=e267]: C6
                - generic [ref=e268]: B5
                - generic [ref=e269]: A♯5
                - generic [ref=e270]: A5
                - generic [ref=e271]: G♯5
                - generic [ref=e272]: G5
                - generic [ref=e273]: F♯5
                - generic [ref=e274]: F5
                - generic [ref=e275]: E5
                - generic [ref=e276]: D♯5
                - generic [ref=e277]: D5
                - generic [ref=e278]: C♯5
                - generic [ref=e279]: C5
                - generic [ref=e280]: B4
                - generic [ref=e281]: A♯4
                - generic [ref=e282]: A4
                - generic [ref=e283]: G♯4
                - generic [ref=e284]: G4
                - generic [ref=e285]: F♯4
                - generic [ref=e286]: F4
                - generic [ref=e287]: E4
                - generic [ref=e288]: D♯4
                - generic [ref=e289]: D4
                - generic [ref=e290]: C♯4
                - generic [ref=e291]: C4
                - generic [ref=e292]: B3
                - generic [ref=e293]: A♯3
              - generic [ref=e294]:
                - button "C6, beat 1, duration 0.25" [ref=e295]:
                  - generic [ref=e296]: C6
                - button "C♯6, beat 1.25, duration 0.25" [ref=e298]:
                  - generic [ref=e299]: C♯6
                - button "C6, beat 1.5, duration 0.25" [ref=e301]:
                  - generic [ref=e302]: C6
                - button "D6, beat 1.75, duration 0.25" [ref=e304]:
                  - generic [ref=e305]: D6
                - button "C6, beat 2, duration 0.25" [ref=e307]:
                  - generic [ref=e308]: C6
                - button "C♯6, beat 2.25, duration 0.25" [ref=e310]:
                  - generic [ref=e311]: C♯6
                - button "C6, beat 2.5, duration 0.25" [ref=e313]:
                  - generic [ref=e314]: C6
                - button "D6, beat 2.75, duration 0.25" [ref=e316]:
                  - generic [ref=e317]: D6
          - paragraph [ref=e319]: Drag notes to move them; drag the right edge to resize. Arrow keys edit a focused note.
          - generic [ref=e320]:
            - generic [ref=e321]:
              - strong [ref=e322]: Note details
              - generic [ref=e323]: Choose a note in the piano roll.
            - group "Selected note" [ref=e324]:
              - generic [ref=e326]:
                - text: Pitch (MIDI)
                - spinbutton "Pitch (MIDI)" [disabled] [ref=e327]: "60"
              - generic [ref=e328]:
                - text: Start beat
                - spinbutton "Start beat" [disabled] [ref=e329]: "1"
              - generic [ref=e330]:
                - text: Duration (beats)
                - spinbutton "Duration (beats)" [disabled] [ref=e331]: "1"
              - generic [ref=e332]:
                - text: Velocity
                - spinbutton "Velocity" [disabled] [ref=e333]: "0.8"
              - button "Apply note" [disabled] [ref=e334]
              - button "Discard note edits" [disabled] [ref=e335]
              - button "Delete note" [disabled] [ref=e336]
          - group "Note articulation" [ref=e337]:
            - generic [ref=e339]: Split at beat
            - textbox "Split at beat" [disabled] [ref=e340]
            - button "Split selected note" [disabled] [ref=e341]
            - button "Join next matching note" [disabled] [ref=e342]
            - paragraph [ref=e343]: Song beats start at 1. Enter an exact point inside this note, leaving at least 0.25 beats on both sides. Each half starts a new attack and release, including its echo. No grid snapping. Join combines this note with exactly one touching next note of the same pitch and velocity into a sustained voice (at most 16 beats). Only boundary roundoff is normalized. Undo restores the originals.
          - group "Build a chord" [ref=e344]:
            - generic [ref=e346]: Chord quality
            - combobox "Chord quality" [disabled] [ref=e347]:
              - option "Major" [disabled] [selected]
              - option "Minor" [disabled]
              - option "Suspended 2" [disabled]
              - option "Suspended 4" [disabled]
            - button "Add chord tones" [disabled] [ref=e348]
            - button "Raise lowest chord voice" [disabled] [ref=e349]
            - button "Lower highest chord voice" [disabled] [ref=e350]
            - paragraph [ref=e351]: "Cycle distinct voices at the selected note’s exact onset: move the lowest above the highest, or highest below the lowest, by whole octaves. Wide chords can need several octaves. Timing, lengths and expression stay fixed. Refuse C2–C7 overflow or a new same-pitch overlap. Each cycle is one Undo edit; this does not infer harmony."
            - paragraph [ref=e352]: Add two editable tones above the selected root, with the same timing and velocity. Refuse overlapping existing target tones, pitches above C7 or insufficient note space. Finish unapplied edits first. Undo restores the original. This is an explicit interval tool; it does not infer a key or harmony.
          - group [ref=e353]:
            - generic "Roll chord attacks" [ref=e354]
            - option "Low to high" [disabled] [selected]
            - option "High to low" [disabled]
            - option "0.25 beats" [disabled] [selected]
            - option "0.5 beats" [disabled]
            - option "1 beat" [disabled]
          - region [ref=e355]:
            - paragraph [ref=e356]: LEARN FROM YOUR OWN ENDING
            - heading "Continue this phrase" [level=2] [ref=e357]
            - paragraph [ref=e358]: A local pattern suggestion learned only from this ending. Small samples often repeat; this does not learn your general style or judge musical quality.
            - generic [ref=e359]:
              - generic [ref=e360]:
                - text: Learn from last notes
                - textbox "Learn from last notes" [ref=e361]: "8"
              - generic [ref=e362]:
                - text: Suggested notes
                - combobox "Suggested notes" [ref=e363]:
                  - option "4 notes" [selected]
                  - option "8 notes"
              - button "Suggest continuation" [ref=e364] [cursor=pointer]
            - paragraph [ref=e365]: "Destination high notes: 8 source notes · 7 observed transitions · C6 to D6 · beats 1–3"
            - paragraph [ref=e366]: Use 8–64 audible, nonoverlapping notes on a quarter-beat grid, spanning at most 16 beats. Suggestions add at most 16 beats. Repeat phrase remains available for an exact copy.
      - region [ref=e367]:
        - generic [ref=e368]:
          - paragraph [ref=e369]: ARRANGEMENT AUDITION
          - heading "Work on a section." [level=2] [ref=e370]
          - paragraph [ref=e371]: Beats start at 1; the end is exclusive. Committed synthesized mix only. Session-only range; hard loop boundaries can click. Duplicate inserts after the end. Remove deletes the section and closes the gap on all tracks. Crossing notes must be included whole; reference recordings stay unchanged. Move relocates whole notes to an empty destination window, leaves a gap and does not shift other notes. Song-time automation and references stay anchored. All edits support Undo. End beat at most 9.
        - generic [ref=e372]:
          - generic [ref=e373]:
            - text: Section start beat
            - textbox "Section start beat" [ref=e374]: "1"
          - generic [ref=e375]:
            - text: Section end beat (exclusive)
            - textbox "Section end beat (exclusive)" [ref=e376]: "5"
          - generic [ref=e377]:
            - text: Move section to beat
            - textbox "Move section to beat" [ref=e378]: "1"
          - button "Play section" [ref=e379] [cursor=pointer]
          - button "Loop section" [ref=e380] [cursor=pointer]
          - button "Duplicate section" [ref=e381] [cursor=pointer]
          - button "Remove section and close gap" [ref=e382] [cursor=pointer]
          - button "Move section" [ref=e383] [cursor=pointer]
          - button "Export section WAV" [ref=e384] [cursor=pointer]
      - region [ref=e385]:
        - generic [ref=e386]:
          - paragraph [ref=e387]: NOTE TIMING
          - heading "Tighten the rhythm." [level=2] [ref=e388]
          - paragraph [ref=e389]: Use the section range above on the selected track. Move original note starts toward the nearest song grid; midpoint ties go later. Strength 0 keeps timing, 1 fully aligns. Starts action keeps lengths; durations action keeps starts and snaps held lengths to positive grid multiples of at least 0.25 beats. Duration ties go longer; notes may extend beyond the section end. Pitches and dynamics stay fixed, with no ripple. Timeline overflow refuses. Session-only settings; Apply supports Undo.
        - generic [ref=e390]:
          - generic [ref=e391]:
            - text: Quantize grid
            - combobox "Quantize grid" [ref=e392]:
              - option "One beat"
              - option "Half beat"
              - option "Quarter beat" [selected]
              - option "Eighth beat"
          - generic [ref=e393]:
            - text: Quantize strength
            - textbox "Quantize strength" [ref=e394]: "1"
          - button "Quantize section note starts" [ref=e395] [cursor=pointer]
          - button "Quantize section note durations" [ref=e396] [cursor=pointer]
      - region [ref=e397]:
        - generic [ref=e398]:
          - paragraph [ref=e399]: PHRASE VARIATION
          - heading "Create a phrase variation." [level=2] [ref=e400]
          - paragraph [ref=e401]: Use the section range above on the selected track. Change pitches at original onsets, keeping whole note lengths and dynamics. Invert mirrors intervals around the lowest pitch at the earliest included onset. Any result outside C2–C7 refuses the whole edit. Reverse mirrors whole note intervals and rests inside the section, keeping pitch and length; crossing notes refuse. Stretch/compress scales whole intervals and rests, shifting later notes only on this track. Other tracks, tempo, reference recordings and song-time volume ramps stay anchored. Duration/timeline limits refuse rather than clamp; each change supports Undo.
        - generic [ref=e402]:
          - button "Transpose section down an octave" [ref=e403] [cursor=pointer]
          - button "Transpose section down a semitone" [ref=e404] [cursor=pointer]
          - button "Transpose section up a semitone" [ref=e405] [cursor=pointer]
          - button "Transpose section up an octave" [ref=e406] [cursor=pointer]
          - button "Invert section pitches" [ref=e407] [cursor=pointer]
          - button "Reverse section note timing" [ref=e408] [cursor=pointer]
          - button "Stretch section timing ×2" [ref=e409] [cursor=pointer]
          - button "Compress section timing ×0.5" [ref=e410] [cursor=pointer]
      - region [ref=e411]:
        - generic [ref=e412]:
          - paragraph [ref=e413]: PHRASE DYNAMICS
          - heading "Shape a crescendo." [level=2] [ref=e414]
          - paragraph [ref=e415]: Use the section range above on the selected track. Ramp from the first to the last distinct note onset; chords share a velocity. At least two onsets are needed. Values 0–1; zero is silent and omitted from MIDI. Timing, other tracks and reference recordings stay unchanged. Parameters are session-only; Apply is one reversible saved edit.
        - generic [ref=e416]:
          - generic [ref=e417]:
            - text: Ramp start velocity
            - textbox "Ramp start velocity" [ref=e418]: "0.3"
          - generic [ref=e419]:
            - text: Ramp end velocity
            - textbox "Ramp end velocity" [ref=e420]: "0.9"
          - button "Apply velocity ramp" [ref=e421] [cursor=pointer]
      - region [ref=e422]:
        - generic [ref=e423]:
          - paragraph [ref=e424]: 03 / KEEP IT GOING
          - heading "Take your idea with you." [level=2] [ref=e425]
          - paragraph [ref=e426]: Saved in this browser
        - generic [ref=e427]:
          - button "Save project file" [ref=e428] [cursor=pointer]
          - generic [ref=e429] [cursor=pointer]:
            - text: Open project
            - button "Open project file" [ref=e430]
          - button "Export MIDI" [ref=e431] [cursor=pointer]
          - button "Export MIDI with volume automation" [ref=e432] [cursor=pointer]
          - button "Export WAV" [ref=e433] [cursor=pointer]
          - button "Export track WAV" [ref=e434] [cursor=pointer]
      - generic [ref=e435]:
        - generic [ref=e436]:
          - button "Load example" [ref=e437] [cursor=pointer]
          - button "New project" [ref=e438] [cursor=pointer]
        - paragraph [ref=e439]: A music sketchbook, built for first ideas. Single-voice pitch detection, editable by you.Successful takes retain a normalized listen-back copy on this device. Export a project backup before clearing browser data.
    - region [ref=e440]:
      - generic [ref=e441]:
        - paragraph [ref=e442]: EDIT MUSICAL TIMING
        - heading "Tighten this track’s timing." [level=2] [ref=e443]
        - paragraph [ref=e444]: Review onsets before applying. Durations, pitches, velocities and reference audio stay unchanged. Swing delays odd subdivisions within each two-grid pair. Ties choose the later onset; shifts beyond the song limit refuse the whole edit.
      - generic [ref=e445]:
        - generic [ref=e446]:
          - generic [ref=e447]: Timing grid (beats)
          - combobox "Timing grid (beats)" [ref=e448]:
            - option "1 beat"
            - option "½ beat"
            - option "¼ beat" [selected]
            - option "⅛ beat"
        - generic [ref=e449]:
          - text: Timing strength (%)
          - textbox "Timing strength (%)" [ref=e450]: "100"
        - generic [ref=e451]:
          - text: Timing swing (%)
          - textbox "Timing swing (%)" [ref=e452]: "0"
      - generic [ref=e453]:
        - button "Review timing" [ref=e454] [cursor=pointer]
        - button "Audition timing" [disabled] [ref=e455]
        - button "Apply timing" [disabled] [ref=e456]
        - button "Discard timing" [disabled] [ref=e457]
      - status [ref=e458]: Choose a grid, strength 0–100%, and swing 0–50%. Review changes to the selected track.
    - region [ref=e459]:
      - paragraph [ref=e460]: KEEP COMPLETE COPIES
      - heading "Saved compositions" [level=2] [ref=e461]
      - paragraph [ref=e462]: Keep up to eight complete copies. Copies change only when you choose Save new copy or Update selected copy. Your current workspace autosaves separately.
      - generic [ref=e463]:
        - generic [ref=e464]:
          - text: Saved-copy label
          - textbox "Saved-copy label" [ref=e465]
        - generic [ref=e466]:
          - text: Saved composition
          - combobox "Saved composition" [ref=e467]:
            - option "Choose a saved copy" [selected]
      - paragraph [ref=e468]: Use 1–80 characters. Labels are separate from composition titles; duplicate labels are allowed.
      - paragraph [ref=e469]: No saved copy selected.
      - generic [ref=e470]:
        - button "Save new copy" [ref=e471] [cursor=pointer]
        - button "Update selected copy" [disabled] [ref=e472]
        - button "Open selected copy" [disabled] [ref=e473]
        - button "Refresh copies" [ref=e474] [cursor=pointer]
      - generic [ref=e475]:
        - button "Download selected copy" [disabled] [ref=e476]
        - button "Delete selected copy" [disabled] [ref=e477]
        - button "Cancel library operation" [disabled] [ref=e478]
      - status [ref=e479]: Choose Refresh copies to list saved compositions.
    - region [ref=e480]:
      - paragraph [ref=e481]: LISTEN BACK AND CORRECT
      - heading "Reference take" [level=2] [ref=e482]
      - paragraph [ref=e483]: audio-file supplied capture · captured 240 BPM · current 240 BPM · 0.5 seconds · decoded 22050 Hz / 1 channels. Mono PCM16 normalized copy at 22050 Hz, with lossy quantization/resampling; not amplitude normalized.
      - generic [ref=e484]:
        - generic [ref=e485]:
          - generic [ref=e486]:
            - text: Comparison start (seconds)
            - textbox "Comparison start (seconds)" [ref=e487]: "0"
          - generic [ref=e488]:
            - text: Comparison end (seconds)
            - textbox "Comparison end (seconds)" [ref=e489]: "0.5"
        - paragraph [ref=e490]: "Effective comparison: 0–0.5 seconds, 11025 samples. Notes outside this window are not compared; use ordinary Play for the full arrangement."
        - generic [ref=e491]:
          - button "Play reference" [ref=e492] [cursor=pointer]
          - button "Play edited notes at capture tempo" [ref=e493] [cursor=pointer]
          - button "Remove reference" [ref=e494] [cursor=pointer]
        - paragraph [ref=e495]: Reference audio ignores track mute and volume. Notes audition uses applied notes, current instrument/volume/velocity and captured BPM. No time stretching or device-delay correction; quantization/resampling is lossy.
      - paragraph [ref=e496]: Auditions use applied notes. Reference audio ignores track mute and volume and plays at its retained level.
      - button "Clear undo history" [ref=e498] [cursor=pointer]
      - paragraph [ref=e499]: Save project file carries current notes and reference takes, not history or unapplied fields. Browser tabs do not merge edits. A changed saved copy pauses saving until you review it. Download a complete backup before clearing browser data.
    - region [ref=e500]:
      - generic [ref=e501]:
        - generic [ref=e502]:
          - paragraph [ref=e503]: BRING IN A WRITTEN PHRASE
          - heading "MIDI import" [level=2] [ref=e504]
          - paragraph [ref=e505]: Choose parts and instruments, review a phrase, then replace deliberately. Nothing is saved during review.
        - generic [ref=e506] [cursor=pointer]:
          - text: Import MIDI file
          - button "Import MIDI file" [ref=e507]
      - paragraph [ref=e508]: MIDI import cancelled. Your composition, drafts and suggestion are unchanged.
      - generic [ref=e509]:
        - button "Review MIDI phrase" [disabled] [ref=e510]
        - button "Cancel MIDI import" [ref=e511] [cursor=pointer]
      - button "Replace composition" [disabled] [ref=e512]
```

# Test source

```ts
  1  | import { expect, type Page } from '@playwright/test';
  2  | import { readFile } from 'node:fs/promises';
  3  | import { createHash } from 'node:crypto';
  4  | import { decodeMidi, decodeWav } from './browser/continuation-fixtures.ts';
  5  | export interface OriginalNote {id:string;pitch:number;start:number;duration:number;velocity:number}
  6  | export interface OriginalTrack {id:string;name:string;instrument:'sine';volume:number;muted:boolean;notes:OriginalNote[]}
  7  | export interface OriginalAsset {id:string;kind:string;captureTempo:number;decodedSampleRate:number;decodedChannels:number;decodedFrames:number;analyzedFrames:number;frameCount:number;sha256:string;pcmBase64:string}
  8  | export interface CompleteBackup {format:string;version:number;document:{schemaVersion:number;composition:{version:number;title:string;tempo:number;tracks:OriginalTrack[]};references:{trackId:string;assetId:string}[]};assets:OriginalAsset[]}
  9  | export const hash=(bytes:Uint8Array)=>createHash('sha256').update(bytes).digest('hex');
  10 | export function originalBacking(title='Original backed recording Ω'):CompleteBackup{
  11 |  const target:OriginalTrack={id:'target',name:'Destination high notes',instrument:'sine',volume:1,muted:false,notes:[84,85,84,86,84,85,84,86].map((pitch,i)=>({id:`old-${i}`,pitch,start:i*.25,duration:.25,velocity:.8}))};
  12 |  const tracks:OriginalTrack[]=[target,{id:'backing',name:'Audible low backing',instrument:'sine',volume:.25,muted:false,notes:[{id:'low-a',pitch:48,start:0,duration:4,velocity:.5},{id:'low-b',pitch:52,start:4,duration:4,velocity:.5}]},{id:'muted',name:'Muted high sentinel',instrument:'sine',volume:1,muted:true,notes:[{id:'muted-note',pitch:96,start:0,duration:8,velocity:1}]},{id:'zero',name:'Zero volume sentinel',instrument:'sine',volume:0,muted:false,notes:[{id:'zero-note',pitch:90,start:0,duration:8,velocity:1}]}];
  13 |  const assets=tracks.map((_,i)=>{const pcm=Buffer.alloc(22050);for(let n=0;n<11025;n++)pcm.writeInt16LE(Math.round(5000*Math.sin(2*Math.PI*(330+55*i)*n/22050)),n*2);return{id:`1130000${i}-0000-4000-8000-000000000001`,kind:'audio-file',captureTempo:240,decodedSampleRate:22050,decodedChannels:1,decodedFrames:11025,analyzedFrames:11025,frameCount:11025,sha256:hash(pcm),pcmBase64:pcm.toString('base64')};});
  14 |  return{format:'melody-studio-project',version:1,document:{schemaVersion:1,composition:{version:1,title,tempo:240,tracks},references:tracks.map((track,i)=>({trackId:track.id,assetId:assets[i].id}))},assets};
  15 | }
  16 | export async function backup(page:Page):Promise<CompleteBackup>{const waiting=page.waitForEvent('download');await page.getByRole('button',{name:'Save project file',exact:true}).click();const path=await(await waiting).path();if(!path)throw Error('Native project download unavailable');const value=JSON.parse((await readFile(path)).toString())as CompleteBackup;for(const asset of value.assets){const pcm=Buffer.from(asset.pcmBase64,'base64');expect(hash(pcm)).toBe(asset.sha256);expect(pcm.length).toBe(asset.frameCount*2);}return value;}
  17 | export async function open(page:Page,fixture=originalBacking()){await page.goto('/');await expect(page.getByLabel('Open project file',{exact:true})).toBeEnabled();page.once('dialog',d=>d.accept());await page.getByLabel('Open project file',{exact:true}).setInputFiles({name:'original-backed.melody.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(fixture))});await expect(page.getByLabel('Project title')).toHaveValue(fixture.document.composition.title);await expect(page.locator('#save-status')).toHaveText('Saved in this browser');await page.locator('[data-track=target]').click();}
  18 | interface ObservedSource {sampleRate:number;frames:number;when:number;contextRate:number;samples:number[]}
  19 | interface Probe {requests:number;stopped:number;sources:ObservedSource[];releasePermission:(()=>void)|null;elapsed:()=>number;stream:MediaStream|null;renderRequests:number}
  20 | type ProbeWindow=Window&{backed113:Probe};
  21 | export async function microphone(page:Page,pending=false,silent=false){await page.addInitScript(({pending,silent})=>{
  22 |  const state:Probe={requests:0,stopped:0,sources:[],releasePermission:null,elapsed:()=>-Infinity,stream:null,renderRequests:0};(window as unknown as ProbeWindow).backed113=state;
  23 |  const native=AudioContext.prototype.createBufferSource;
  24 |  AudioContext.prototype.createBufferSource=function(){const source=native.call(this),start=source.start.bind(source),context=source.context;source.start=(...args:Parameters<AudioBufferSourceNode['start']>)=>{const b=source.buffer;if(b){const when=args[0]??context.currentTime;state.sources.push({sampleRate:b.sampleRate,frames:b.length,when,contextRate:context.sampleRate,samples:b.length===441000?Array.from(b.getChannelData(0).subarray(0,66150)):[]});if(b.length===441000)state.elapsed=()=>context.currentTime-when;}start(...args);};return source;};
  25 |  Object.defineProperty(navigator.mediaDevices,'getUserMedia',{configurable:true,value:async()=>{state.requests++;state.elapsed=()=>-Infinity;const context=new AudioContext(),tone=context.createOscillator(),gain=context.createGain(),destination=context.createMediaStreamDestination();tone.frequency.value=440;gain.gain.value=silent?0:.25;tone.connect(gain).connect(destination);tone.start();const stream=destination.stream;state.stream=stream;for(const track of stream.getTracks()){const stop=track.stop.bind(track);track.stop=()=>{if(track.readyState==='ended')return;state.stopped++;stop();tone.stop();void context.close();};}await context.resume();if(pending)await new Promise<void>(done=>state.releasePermission=done);return stream;}});
  26 |  },{pending,silent});}
  27 | export async function probe(page:Page){return page.evaluate(()=>{const p=(window as unknown as ProbeWindow).backed113;return{requests:p.requests,stopped:p.stopped,sources:p.sources,elapsed:p.elapsed(),released:p.stream?.getTracks().every(t=>t.readyState==='ended')??false};});}
> 28 | export async function awaitElapsed(page:Page,seconds:number){await expect.poll(()=>page.evaluate(()=>(window as unknown as ProbeWindow).backed113.elapsed())).toBeGreaterThan(seconds);}
     |                                                                                                                                                               ^ Error: expect(received).toBeGreaterThan(expected)
  29 | export async function releasePermission(page:Page){await page.evaluate(()=>(window as unknown as ProbeWindow).backed113.releasePermission?.());}
  30 | export async function released(page:Page){await expect.poll(async()=>{const p=await probe(page);return p.stopped>0&&p.released;}).toBe(true);}
  31 | export function assertBacking(samples:number[]){expect(samples).toHaveLength(66150);let largest=0;for(let i=0;i<samples.length;i++){let want=0;for(const [pitch,start]of[[48,0],[52,22050]]){const local=i-start;if(local<0||local>=23814)continue;const envelope=local<220.5?local/220.5:local<=22050?1:Math.max(0,1-(local-22050)/1764);want+=Math.sin(2*Math.PI*(440*2**((pitch-69)/12))*local/22050)*envelope*.25*.5*.4;}largest=Math.max(largest,Math.abs(samples[i]-want));}expect(largest).toBeLessThanOrEqual(5e-8);expect(samples.slice(45864).every(n=>n===0)).toBe(true);return largest;}
  32 | export function assertMicrophone(asset:OriginalAsset){const pcm=Buffer.from(asset.pcmBase64,'base64');expect(asset.kind).toBe('microphone');expect(asset.captureTempo).toBe(240);expect(asset.frameCount).toBeGreaterThan(22050);expect(asset.frameCount).toBeLessThanOrEqual(441000);let power=0,crossings=0;const start=2205,end=Math.min(asset.frameCount-1,start+22050);for(let i=start;i<end;i++){const x=pcm.readInt16LE(i*2)/32768;power+=x*x;if(i>start&&pcm.readInt16LE((i-1)*2)<=0&&x>0)crossings++;}const rms=Math.sqrt(power/(end-start)),hz=crossings*22050/(end-start);expect(Math.abs(rms-.1768)).toBeLessThan(.015);expect(Math.abs(hz-440)).toBeLessThanOrEqual(2);return{rms,hz,frames:asset.frameCount,sha256:asset.sha256};}
  33 | export async function stored(page:Page){return page.evaluate(()=>new Promise<{row:unknown;assets:{id:string;sha256:string;bytes:number[]}[]}>((resolve,reject)=>{const req=indexedDB.open('melody-studio.projects');req.onerror=()=>reject(req.error);req.onsuccess=()=>{const db=req.result,tx=db.transaction(['projects','assets'],'readonly'),row=tx.objectStore('projects').get('current'),assets=tx.objectStore('assets').getAll();tx.oncomplete=()=>{db.close();void Promise.all((assets.result as{id:string;sha256:string;pcm:Blob}[]).map(async asset=>({id:asset.id,sha256:asset.sha256,bytes:[...new Uint8Array(await asset.pcm.arrayBuffer())]}))).then(values=>resolve({row:row.result,assets:values}),reject);};tx.onabort=()=>{db.close();reject(tx.error);};};}));}
  34 | 
  35 | export async function exportBytes(page:Page,name:string){const waiting=page.waitForEvent('download');await page.getByRole('button',{name,exact:true}).click();const path=await(await waiting).path();if(!path)throw Error('Native export unavailable');return readFile(path);}
  36 | export function assertExports(midiBytes:Buffer,wavBytes:Buffer,backup:CompleteBackup){const project=backup.document.composition,midi=decodeMidi(midiBytes);expect(midi.ticksPerBeat).toBe(480);expect(midi.microsecondsPerBeat).toBe(250000);project.tracks.forEach((track,index)=>expect(midi.tracks[index+1].notes).toEqual((track.muted?[]:track.notes).map(note=>{const start=Math.round(note.start*480),end=Math.round((note.start+note.duration)*480);return{pitch:note.pitch,start:start/480,duration:(end-start)/480,velocity:Math.max(1,Math.round(note.velocity*127))};}).sort((a,b)=>a.start-b.start||a.pitch-b.pitch)));const wav=decodeWav(wavBytes),rate=22050;expect(wav.sampleRate).toBe(rate);const end=Math.max(...project.tracks.flatMap(track=>track.notes.map(note=>note.start+note.duration)));expect(wav.samples.length).toBe(Math.ceil((end/4+.08)*rate));let maximum=0;for(let index=0;index<wav.samples.length;index+=37){let value=0;for(const track of project.tracks)if(!track.muted)for(const note of track.notes){const i=index-Math.round(note.start/4*rate),duration=note.duration/4*rate;if(i<0||i>=Math.ceil(duration+.08*rate))continue;const envelope=i<.01*rate?i/(.01*rate):i<=duration?1:Math.max(0,1-(i-duration)/(.08*rate));value+=Math.sin(2*Math.PI*(440*2**((note.pitch-69)/12))*i/rate)*envelope*track.volume*note.velocity*.4;}const wanted=Math.round(value*(value<0?32768:32767));maximum=Math.max(maximum,Math.abs(wav.samples[index]-wanted));}expect(maximum).toBeLessThanOrEqual(2);return{ticksPerBeat:480,wavSampleRate:rate,wavFrames:wav.samples.length,maximumSignedPcmError:maximum};}
  37 | 
```